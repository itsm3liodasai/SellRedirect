package me.sellredirect;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;

public class SellRedirect extends JavaPlugin implements Listener {

    private final Map<String, String> redirects = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadRedirects();
        getServer().getPluginManager().registerEvents(this, this);
    }

    private void loadRedirects() {
        redirects.clear();
        var section = getConfig().getConfigurationSection("redirects");
        if (section == null) return;
        for (String from : section.getKeys(false)) {
            String to = section.getString(from);
            if (to != null && !to.isBlank()) {
                redirects.put(from.toLowerCase(), to);
            }
        }
    }

    // HIGHEST: başka bir pluginin (örn. Essentials) /sell komutundan önce yakalar
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String msg = e.getMessage();           // "/sell hand"
        if (msg.length() < 2) return;

        String body = msg.substring(1);        // "sell hand"
        int space = body.indexOf(' ');
        String label = (space == -1 ? body : body.substring(0, space)).toLowerCase();
        String args = space == -1 ? "" : body.substring(space);   // " hand"

        String target = redirects.get(label);
        if (target != null) {
            e.setMessage("/" + target + args);
        }
    }
}
